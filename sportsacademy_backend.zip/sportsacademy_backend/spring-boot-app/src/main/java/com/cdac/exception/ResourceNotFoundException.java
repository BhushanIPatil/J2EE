package com.cdac.exception;

public class ResourceNotFoundException {

}
